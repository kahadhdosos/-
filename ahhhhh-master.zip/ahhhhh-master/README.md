### تونسو و ادعولي
 ###  https://t.me/B_8_1     
  
  ### https://t.me/S8Y8S

### A للتنصيب على هيروكو

- Click on  [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TheTepthon/ahhhhh)
